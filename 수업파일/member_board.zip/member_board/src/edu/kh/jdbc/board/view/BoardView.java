package edu.kh.jdbc.board.view;

public class BoardView {

	public void boardMenu() {
		// TODO Auto-generated method stub
		
	}

}
