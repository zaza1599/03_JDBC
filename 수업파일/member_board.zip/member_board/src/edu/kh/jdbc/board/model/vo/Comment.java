package edu.kh.jdbc.board.model.vo;

public class Comment {

}
